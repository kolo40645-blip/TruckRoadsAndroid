import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const $=id=>document.getElementById(id);
const scene=new THREE.Scene(); scene.background=new THREE.Color(0x9ac6d7); scene.fog=new THREE.Fog(0x9ac6d7,90,420);
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,1000);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xd8f1ff,0x536b3c,2.1));
const sun=new THREE.DirectionalLight(0xffedcf,3);sun.position.set(-80,130,60);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);scene.add(sun);
const mat=(color,roughness=.8)=>new THREE.MeshStandardMaterial({color,roughness});
const grass=mat(0x598653),roadMat=mat(0x343a3d),lineMat=mat(0xf4e9b5),white=mat(0xe9e8df),dark=mat(0x18252c),glass= new THREE.MeshStandardMaterial({color:0x4b7b8d,metalness:.2,roughness:.2}),tire=mat(0x171a1b),green=mat(0x66dc9e),buildingMats=[0xc5b6a0,0xb7c6c7,0xd2c7b5,0x8faaa6].map(c=>mat(c));
const ground=new THREE.Mesh(new THREE.PlaneGeometry(1200,1200),grass);ground.rotation.x=-Math.PI/2;ground.position.y=-.2;ground.receiveShadow=true;scene.add(ground);
function box(parent,w,h,d,material,x,y,z){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
function cylinder(parent,r,h,material,x,y,z,rotZ=0){const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,16),material);m.rotation.z=rotZ;m.position.set(x,y,z);m.castShadow=true;parent.add(m);return m}
// Roads: main east-west highway, crossing country roads and lane markings.
function road(x,z,w,d){const m=new THREE.Mesh(new THREE.PlaneGeometry(w,d),roadMat);m.rotation.x=-Math.PI/2;m.position.set(x,.005,z);m.receiveShadow=true;scene.add(m)}
road(0,0,1000,15);road(20,-95,14,210);road(-150,90,12,180);road(130,100,12,190);road(0,205,700,12);
for(let x=-490;x<500;x+=12){const dash=new THREE.Mesh(new THREE.PlaneGeometry(5,.22),lineMat);dash.rotation.x=-Math.PI/2;dash.position.set(x,.018,0);scene.add(dash)}
for(let z=-190;z<10;z+=12){const dash=new THREE.Mesh(new THREE.PlaneGeometry(.22,5),lineMat);dash.rotation.x=-Math.PI/2;dash.position.set(20,.018,z);scene.add(dash)}
// fields and a scenic European roadside town
for(let i=0;i<180;i++){const x=(Math.random()-.5)*850,z=(Math.random()-.5)*700;if(Math.abs(z)<24||Math.abs(x-20)<23||Math.abs(z-205)<20||Math.abs(x+150)<20||Math.abs(x-130)<20)continue;
 if(Math.random()<.67){const h=4+Math.random()*15,w=5+Math.random()*10,d=5+Math.random()*10;const b=box(scene,w,h,d,buildingMats[Math.floor(Math.random()*buildingMats.length)],x,h/2-.15,z);if(Math.random()<.6){for(let s=-1;s<=1;s+=2)box(scene,.45,.6,.12,glass,x+s*w*.25,h*.6,z+d/2+.07)}}
 else {const trunk=box(scene,.7,3,.7,mat(0x76543a),x,1.3,z);const crown=new THREE.Mesh(new THREE.ConeGeometry(3+Math.random()*2,7,7),mat(0x2c653e));crown.position.set(x,5,z);crown.castShadow=true;scene.add(crown)}
}
// signs and gas station
box(scene,1,5,1, dark, -12,2.5,-11);box(scene,8,2.2,.35,green,-12,5,-11); 
const signTextCanvas=document.createElement('canvas');signTextCanvas.width=512;signTextCanvas.height=128;const ctx=signTextCanvas.getContext('2d');ctx.fillStyle='#102b25';ctx.fillRect(0,0,512,128);ctx.fillStyle='#8af0b6';ctx.font='bold 50px Arial';ctx.fillText('UTRECHT  24 km',24,80);const signTex=new THREE.CanvasTexture(signTextCanvas);const sign=new THREE.Mesh(new THREE.PlaneGeometry(7.8,1.9),new THREE.MeshBasicMaterial({map:signTex}));sign.position.set(-12,5,-10.8);scene.add(sign);
const gas=box(scene,13,4,10,mat(0xe6e5d8),-36,2,-22);box(scene,14,.5,11,green,-36,4.1,-22);box(scene,2,2,1,mat(0xd83f3f),-30,1,-17);
function makeTruck(color){const root=new THREE.Group();const cab=box(root,2.6,2.6,3,mat(color,.4),0,2.05,-1.4);box(root,2.4,1.2,4.6,white,0,1.15,3.1);box(root,2.25,1.05,.12,glass,0,2.55,-2.93);box(root,.35,.25,.15,mat(0xfff1bd),-.9,.95,-2.95);box(root,.35,.25,.15,mat(0xfff1bd),.9,.95,-2.95);box(root,.2,.5,.2,dark,-1.1,3.5,-1.3);box(root,.2,.5,.2,dark,1.1,3.5,-1.3);
 for(const z of [-2.2,.2,3.4,4])for(const x of [-1.35,1.35]){const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.53,.53,.32,20),tire);wheel.rotation.z=Math.PI/2;wheel.position.set(x,.62,z);wheel.castShadow=true;root.add(wheel);const hub=new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,.34,16),mat(0x9da5a8,.35));hub.rotation.z=Math.PI/2;hub.position.set(x*1.01,.62,z);root.add(hub)}
 root.position.set(0,0,0);scene.add(root);return root}
const colors=[0xb92f32,0x2478a8,0xd8a52c,0x385b4c];let truck=makeTruck(colors[0]);let speed=0,fuel=100,cash=2500,steer=0,cameraMode=0;const keys={};let started=false,delivered=false;
const marker=new THREE.Group();const ring=new THREE.Mesh(new THREE.TorusGeometry(4,.25,8,32),green);ring.rotation.x=Math.PI/2;ring.position.y=.3;marker.add(ring);const beam=new THREE.Mesh(new THREE.CylinderGeometry(.2,.8,8,12,1,true),new THREE.MeshBasicMaterial({color:0x66dc9e,transparent:true,opacity:.18,side:THREE.DoubleSide}));beam.position.y=4;marker.add(beam);marker.position.set(20,0,-95);scene.add(marker);
function updateHUD(){$('speed').textContent=Math.round(Math.abs(speed)*3.6);$('fuel').textContent=Math.round(fuel);$('cash').textContent='€ '+cash.toLocaleString('pl-PL')}
function toast(t){$('toast').textContent=t;$('toast').style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').style.display='none',3200)}
function reset(){truck.position.set(0,0,0);truck.rotation.y=0;speed=0;steer=0;toast('Ciężarówka ustawiona na drodze.')}
function setKey(k,v){keys[k]=v}
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();setKey(k==='arrowup'?'w':k==='arrowdown'?'s':k==='arrowleft'?'a':k==='arrowright'?'d':k,true);if(k==='c')cameraMode=(cameraMode+1)%3;if(k==='r')reset()});
window.addEventListener('keyup',e=>{const k=e.key.toLowerCase();setKey(k==='arrowup'?'w':k==='arrowdown'?'s':k==='arrowleft'?'a':k==='arrowright'?'d':k,false)});
document.querySelectorAll('[data-key]').forEach(b=>{const k=b.dataset.key;b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);setKey(k,true)});for(const ev of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(ev,()=>setKey(k,false))});
$('start').addEventListener('click',()=>{const idx=Number($('truck').value);scene.remove(truck);truck=makeTruck(colors[idx]);$('menu').style.display='none';started=true;toast('Silnik uruchomiony. Powodzenia na trasie!')});
function collision(){// keep truck within playable map; soft roadside drag
 const p=truck.position; if(Math.abs(p.x)>500||Math.abs(p.z)>350){speed*=.8;p.x=THREE.MathUtils.clamp(p.x,-500,500);p.z=THREE.MathUtils.clamp(p.z,-350,350)}
 const onRoad=Math.abs(p.z)<8||Math.abs(p.x-20)<7||Math.abs(p.x+150)<6||Math.abs(p.x-130)<6||Math.abs(p.z-205)<6;
 if(!onRoad&&Math.abs(speed)>.5)speed*=.992;
}
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);if(started){
 if(keys.w||keys.arrowup)speed=Math.min(speed+13*dt,32);else if(keys.s||keys.arrowdown)speed=Math.max(speed-20*dt,-7);else speed*=Math.pow(.985,dt*60);
 if(keys[' '])speed*=Math.pow(.88,dt*60);
 const turn=(keys.a?-1:0)+(keys.d?1:0);steer=THREE.MathUtils.lerp(steer,turn,.08);
 truck.rotation.y-=steer*speed*.018*dt*10;
 truck.position.x+=Math.sin(truck.rotation.y)*speed*dt;truck.position.z+=Math.cos(truck.rotation.y)*speed*dt;
 collision();fuel=Math.max(0,fuel-Math.abs(speed)*dt*.0022);if(fuel===0){speed*=.95}
 marker.rotation.y+=dt*.8;
 if(!delivered&&truck.position.distanceTo(marker.position)<9){delivered=true;cash+=850;fuel=Math.max(0,fuel-3);updateHUD();$('missionTitle').textContent='DOSTAWA ZAKOŃCZONA';$('missionText').textContent='Premia €850. Wróć na drogę i zwiedź okolicę.';toast('Dostawa wykonana! Otrzymujesz €850.');marker.position.set(-36,0,-22);delivered=false; // repeatable drop-off
 }
 if(fuel<18&&Math.abs(truck.position.x+36)<13&&Math.abs(truck.position.z+22)<13){fuel=Math.min(100,fuel+12*dt);if(Math.floor(fuel)%10===0)updateHUD()}
 const offset=cameraMode===0?new THREE.Vector3(0,6,12):cameraMode===1?new THREE.Vector3(0,2,-7):new THREE.Vector3(10,12,10);
 const worldOffset=offset.clone().applyAxisAngle(new THREE.Vector3(0,1,0),truck.rotation.y);const target=truck.position.clone().add(worldOffset);camera.position.lerp(target,1-Math.pow(.001,dt));camera.lookAt(truck.position.x,truck.position.y+1.7,truck.position.z);
 updateHUD();
 }else{camera.position.lerp(new THREE.Vector3(12,10,18),.015);camera.lookAt(0,0,0)}
 renderer.render(scene,camera)}
animate();window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
$('loading').style.display='none';
