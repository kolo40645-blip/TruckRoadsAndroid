TRUCK ROADS — ANDROID APK BUILD PACKAGE

This is an Android WebView wrapper project for the Truck Roads prototype.
It is not itself a compiled APK. Build it using GitHub Actions from a GitHub repository.

BUILD FROM AN ANDROID PHONE:
1. Download and extract this ZIP.
2. In your mobile browser, create a new repository on https://github.com/new.
3. Upload the extracted project files/folders to the repository (keep the .github/workflows/build-apk.yml file).
   GitHub's web upload may be easiest from a browser with "Desktop site" enabled.
4. Open the repository's Actions tab and enable Actions if prompted.
5. Choose "Build Truck Roads APK" on the left, tap "Run workflow", then run it.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to Artifacts, and download "Truck-Roads-APK".
8. Extract the artifact ZIP to get app-debug.apk. Tap it to install.
   Android may ask you to allow installs from that browser/files app. Only allow this for a file you trust.

NOTES:
- Internet is needed for Three.js from the CDN.
- This is a debug APK, not a Play Store release.
- The prototype itself remains basic; no multiplayer or official licensed truck models.
